package Racas
import up.ddm.Atributos

interface iRaca {
    fun aplicarAprimoramento(atributos: Atributos): Atributos
}

